<html lang="es">
<head>
	<meta charset="UTF-8"/>
	<link rel="shortcut icon" href="static/originales/icono.ico"/>
	<meta name="description" content="¡Aquí encontrarás toda la información que necesitas sobre Teamfight Tactics!"/>
	<link href="https://fonts.googleapis.com/css?family=Merriweather&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="static/style/style.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
	<script type=" text/javascript" src="static/js/javascriptIndex.js"></script>
	<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-3261656417999696",
          enable_page_level_ads: true
     });
	</script>
  	<title><?php ?> - TFTESP</title>
<link rel="stylesheet" type="text/css" href="static/style/campeon.css">

</head>
<body id="inicio">
	<div style="display: block;">
		<div id="navbar">
			<a href="index.php">
				<div id="leftbar"><img src="static/originales/logo.png" style="width:110px"></div>
			</a>
			<div id="midbar">
				<a class="navbarlink" href="index.php">INICIO</a>
				<a class="navbarlink" href="campeones.html">CAMPEONES</a>
				<a class="navbarlink" href="objetos.html">OBJETOS</a>
				<a class="navbarlink" href="clases.html">CLASES Y ORIGENES</a>
				<a class="navbarlink" href="composiciones.html">COMPOSICIONES</a>
				<a class="navbarlink" href="constructor.html">CONSTRUCTOR DE EQUIPO</a>
				<a class="navbarlink" href="tabladelideres.php">RANKING</a>
			</div>
			<a href="https://twitter.com/TFT_Esp">
				<div id="rightbar"><img src="static/originales/twitter.png" style="width:18px; padding-top:18px;"></div>
			</a>
			<a href="https://www.instagram.com/tftesp/">
				<div id="rightbar"><img src="static/originales/instagram.png" style="width:34px; padding-top:8px;"></div>
			</a>
			<a href="https://lolesp.com/foros/league-of-legends/general/teamfight-tactics/tft-notas-del-parche-9-16/28447.html">
				<div id="rightbar" style="padding-top:18px; font-size:15px;"><u>Parche: 9.16</u></div>
			</a>
		</div>
<?php
        if(isset($_REQUEST['campeon'])){
                    $con = mysqli_connect("PMYSQL110.dns-servicio.com", "varo", "&qdGw743", "6795849_tftesp");
                    mysqli_set_charset($con,'UTF8');
                    $consulta = 'select * from campeones where nombre = "'.$_REQUEST['campeon'].'"';
                    $resultado = $con->query($consulta);
                    $datos = $resultado->fetch_assoc();
                    if($datos == NULL){
                        $con->close();
                        die();
                    }
                } else {
                    die();
                }
    ?>
   <div style="border:solid; min-width: 1150px; width: 60%; height: 600px;margin:auto;margin-top: 3%;color: #c9aa71; background-color: rgb(18,18,18, 0.75); margin-bottom:100px;">
        <div style="border-bottom:solid;height: 110px;margin:auto; padding-top:20px;display: flex;align-items:center; justify-content: center; background-color: rgb(18,18,18); ">
            <div>
            <?php
                print
                "<img src='static/campeones/". $datos['id']. ".png' style='width:75px;' alt=". $datos['nombre'] ." />"
                ?>
            </div>
            <div style="font-size:70px; margin-left:15px">
                <?php
                    print $datos['nombre'];
                    $resultado2 = $con->query('select * from campeones_clases where id_campeon ='. $datos['id']);
								while($fila2 = $resultado2->fetch_assoc()){
									$resultado3 = $con->query('select * from clases where id ='. $fila2['id_clase']);
									$fila3 = $resultado3->fetch_assoc();
									echo '<img src="static/clases/'.$fila2['id_clase'].'.png" class="oriclasicon" style="margin-left: 5px; width:38px;" title="'.$fila3['nombre'].'" />';
								}
                ?>
            </div>
        </div>

        <?php
            print
            "<div style='float: left; background: url(static/campeonesrender/". $datos['id']. ".png) no-repeat center center;
                 width:40%; height: 460px; background-size: contain;   overflow-y: hidden ! important;
                 overflow-x: hidden ! important;'>
            </div>";
        ?>
        <div style="width:58%; float: left; height:30px;"></div>
        <div style="width:58%; float: left; font-size: 20px; margin-left:10px;margin-top:10px;">
                    <u>
                    <?php
                    print $datos['nombrehabilidad'];
                    ?>
                    </u>
        </div>
        <div style="width:59%; height:100px; float: left;">
                <div style="width:15%; float: left;">
                    <?php
                    print
                    "<img src='static/habilidades/". $datos['id']. ".png' style='width:75px; margin-left:10px;margin-top:10px;' alt=". $datos['nombrehabilidad'] ." />"
                    ?>
                </div>
                <div style="width:78%; float: left; margin-left:10px;margin-top:10px; font-size: 15px;">
                    <?php
                    print $datos['descripcionhabilidad'];

                    ?>
                </div>
            <div style="width: 670px; float:left; overflow-x: hidden ! important;">
            <table id="campeones2">
			<thead>
				<tr>
					<th style="width:10%">Coste</td>
					<th style="width:7%">Vida</td>
					<th style="width:7%">Armadura</td>
					<th style="width:7%">MR</td>
					<th style="width:7%">DPS</td>
					<th style="width:7%">Daño</td>
					<th style="width:7%">Vel. Atq.</td>
					<th style="width:9%">Rango</td>
				</tr>
			</thead>
			<tbody>
						<tr>
							<td><img src="static/originales/oro.png" class="oroicon"><?php echo $datos['precio']?></img></td>
							<td><?php echo $datos['vida']?></td>
							<td><?php echo $datos['armadura']?></td>
							<td><?php echo $datos['rm']?></td>
							<td><?php echo $datos['dps']?></td>
							<td><?php echo $datos['dano']?></td>
							<td><?php echo $datos['vda']?></td>
							<?php
							if($datos['rango'] == 1){
								echo '<td style="font-size: 25px"><b style="color:white">|</b>||||<span class="hidetext">'. $datos['rango'] .'</span></td>';
							}elseif($datos['rango'] == 2){
								echo '<td style="font-size: 25px"><b style="color:white">||</b>|||<span class="hidetext">'. $datos['rango'] .'</span></td>';
							}elseif($datos['rango'] == 3){
								echo '<td style="font-size: 25px"><b style="color:white">|||</b>||<span class="hidetext">'. $datos['rango'] .'</span></td>';
							}elseif($datos['rango'] == 4){
								echo '<td style="font-size: 25px"><b style="color:white">||||</b>|<span class="hidetext">'. $datos['rango'] .'</span></td>';
							}elseif($datos['rango'] == 5){
								echo '<td style="font-size: 25px"><b style="color:white">|||||</b><span class="hidetext">'. $datos['rango'] .'</span></td>';
							}

							?>
						</tr>

			</tbody>
		</table>
        </div>
        <div style="width:58%; float: left; font-size: 20px; margin-left:10px;margin-top:10px;">
                    <u>
                    SINERGIAS
                    </u>
        </div>
        <div style="width:670px; height:250px; float: left; margin-top: 10px;">
        <?php
                    $resultado2 = $con->query('select * from campeones_clases where id_campeon ='. $datos['id']);
								while($fila2 = $resultado2->fetch_assoc()){
									$resultado3 = $con->query('select * from campeones_clases where id_clase ='. $fila2['id_clase'] .' and id_campeon <> ' . $datos['id'] . ' LIMIT 3 ');
									while($fila3 = $resultado3->fetch_assoc()){
                                        echo '<img src="static/campeones/'.$fila3['id_campeon'].'.png" class="oriclasicon" style="margin-left: 5px; width:56px;" />';
                                    }
								}
                ?>
        </div>
        </div>
    </div>
<div id="footer">
	<div style="width: 33%;">
		<div style="width: 415px; margin-top:10px; margin-left:10px;"><img src="static/originales/logo.png" style="width:50%"></img></div>
		<p1 align="bottom" style="margin-left: 20px; ">© 2019 www.tftesp.com<p1></p1>
	</div>
	<div style="width: 33%;">
		<div style="text-align: center; margin-top: 45px;">
			Teamfight Tactics ESP se creó según la política "Galimatías legal" de Riot Games usando
			recursos que
			son propiedad de Riot Games. Riot Games no respalda ni patrocina este proyecto.
		</div>
	</div>
	<div style="width: 33%; text-align: center;">
		<div style="margin-top:45px;">
			<div style="align-items: center;display: flex;width: 30px;margin: auto;">
				<div>
					<a href="https://twitter.com/TFT_Esp">
						<img src="static/originales/twitter.png" style="width:20px;">
					</a>
				</div>
				<div>
					<a href="https://www.instagram.com/tftesp/">
						<img src="static/originales/instagram.png" style="width:34px;">
					</a>
				</div>
			</div>
			<div style="font-size: 10px;margin-top:10px;">
				<u><a href="contactar.html">Contacto</a></u> /
				<u><a href="politica-de-privacidad.html">Politica de privacidad</a></u> /
				<u><a href="terminos-y-condiciones.html">Terminos y condiciones</a></u>
			</div>
		</div>
	</div>
</div>
</div>
</body>

</html>