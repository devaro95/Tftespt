<html lang="es">
<head>
	<meta charset="UTF-8"/>
	<link rel="shortcut icon" href="static/originales/icono.ico"/>
	<meta name="description" content="¡Aquí encontrarás toda la información que necesitas sobre Teamfight Tactics!"/>
	<link href="https://fonts.googleapis.com/css?family=Merriweather&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="static/style/style.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
	<script type=" text/javascript" src="static/js/javascriptIndex.js"></script>
	<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-3261656417999696",
          enable_page_level_ads: true
     });
	</script>
  	<title>Noticias - TFTESP</title>
<link rel="stylesheet" type="text/css" href="static/style/noticia.css">
	<?php 
		$con = mysqli_connect("PMYSQL110.dns-servicio.com", "varo", "&qdGw743", "6795849_tftesp");
		mysqli_set_charset($con,'UTF8');
		$consulta = $con->query('select tipo,titular,descMeta,foto from noticias where slug = "'.$_REQUEST['s'].'"');
		$fila = $consulta->fetch_assoc();
	?>
	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:site" content="@tftesp">
	<meta name="twitter:creator" content="@tftesp">
	<meta name="twitter:title" content= "<?php print "[" . $fila['tipo']. "]" . $fila['titular'];?>">
	<meta name="twitter:description"
		content="<?php print $fila['descMeta']?>">
	<meta name="twitter:image:src" content="<?php print "https://tftesp.com/fotos_head/" . $fila['foto'];?>">
	<link rel="stylesheet" type="text/css" href="static/style/noticia.css">

</head>
<body id="inicio">
	<div style="display: block;">
		<div id="navbar">
			<a href="index.php">
				<div id="leftbar"><img src="static/originales/logo.png" style="width:110px"></div>
			</a>
			<div id="midbar">
				<a class="navbarlink" href="index.php">INICIO</a>
				<a class="navbarlink" href="campeones.html">CAMPEONES</a>
				<a class="navbarlink" href="objetos.html">OBJETOS</a>
				<a class="navbarlink" href="clases.html">CLASES Y ORIGENES</a>
				<a class="navbarlink" href="composiciones.html">COMPOSICIONES</a>
				<a class="navbarlink" href="constructor.html">CONSTRUCTOR DE EQUIPO</a>
				<a class="navbarlink" href="tabladelideres.php">RANKING</a>
			</div>
			<a href="https://twitter.com/TFT_Esp">
				<div id="rightbar"><img src="static/originales/twitter.png" style="width:18px; padding-top:18px;"></div>
			</a>
			<a href="https://www.instagram.com/tftesp/">
				<div id="rightbar"><img src="static/originales/instagram.png" style="width:34px; padding-top:8px;"></div>
			</a>
			<a href="https://tftesp.com/noticia.php?s=notas-parche917">
				<div id="rightbar" style="padding-top:18px; font-size:15px;"><u>Parche: 9.17</u></div>
			</a>
		</div>
<?php
					if(isset($_REQUEST['s'])){
						$con = mysqli_connect("PMYSQL110.dns-servicio.com", "varo", "&qdGw743", "6795849_tftesp");
						mysqli_set_charset($con,'UTF8');
						$consulta = 'select * from noticias where slug = "'.$_REQUEST['s'].'"';
						$resultado = $con->query($consulta);
						$datos = $resultado->fetch_assoc();
						if($datos == NULL){
							$con->close();
							die();
						}
					} else {
						die();
					}
				?>
				<!-- horizontal -->
	<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<ins class="adsbygoogle" style="display:block; text-align:center; margin-bottom: 20px;"
		data-ad-client="ca-pub-3261656417999696" data-ad-slot="3656292990" data-ad-format="auto"
		data-full-width-responsive="true"></ins>
	<script>
		(adsbygoogle = window.adsbygoogle || []).push({});
	</script>
		<div style="position:absolute;left:20px;">
			<div>
				<iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="https://rcm-eu.amazon-adsystem.com/e/cm?ref=tf_til&t=tftesp-21&m=amazon&o=30&p=8&l=as1&IS1=1&asins=B00CJ5FPUE&linkId=cc9d406a0f2a78724c47dc8149389b5c&bc1=FFFFFF&lt1=_top&fc1=333333&lc1=0066C0&bg1=FFFFFF&f=ifr">
				</iframe>
			</div>
			<div>
				<iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="https://rcm-eu.amazon-adsystem.com/e/cm?ref=tf_til&t=tftesp-21&m=amazon&o=30&p=8&l=as1&IS1=1&asins=B0757F3L65&linkId=fc8e0cd29e113c88a93c352f2557dd94&bc1=FFFFFF&lt1=_top&fc1=333333&lc1=0066C0&bg1=FFFFFF&f=ifr">
				</iframe>
			</div>
			<div>
				<iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="https://rcm-eu.amazon-adsystem.com/e/cm?ref=tf_til&t=tftesp-21&m=amazon&o=30&p=8&l=as1&IS1=1&asins=B01MYQ4HJD&linkId=4b0c981dafc1f5303dbd394070500e44&bc1=FFFFFF&lt1=_top&fc1=333333&lc1=0066C0&bg1=FFFFFF&f=ifr">
				</iframe>
			</div>
			<div>
				<iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="https://rcm-eu.amazon-adsystem.com/e/cm?ref=tf_til&t=tftesp-21&m=amazon&o=30&p=8&l=as1&IS1=1&asins=B07DNL7PNB&linkId=1b9ba6a5a2ab55cb4a16a91f3fe3dddf&bc1=FFFFFF&lt1=_top&fc1=333333&lc1=0066C0&bg1=FFFFFF&f=ifr">
				</iframe>
			</div>
			<div>
				<iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="https://rcm-eu.amazon-adsystem.com/e/cm?ref=tf_til&t=tftesp-21&m=amazon&o=30&p=8&l=as1&IS1=1&asins=B07G7MBP49&linkId=050b36963db91666afb527164a1a712b&bc1=FFFFFF&lt1=_top&fc1=333333&lc1=0066C0&bg1=FFFFFF&f=ifr">
				</iframe>
				
			</div>
		</div>
<div id="menuNoticias">
	<div style="background: rgb(18,18,18, 0.75); border: 2px solid #c9aa71;color: #c9aa71">
		<div style="width: 100%;text-align: center">
			<div style="width:100%">
				<img src=<?php echo '"fotos_noticias/'.$datos['foto'].'"'?> style="width: 100%;border-bottom: solid #c9aa71;">
			</div>
			<div id="tituloNoticia">
				<?php echo $datos['titular']; ?> </h1>
			</div>
			<?php $arr = explode(PHP_EOL,$datos['noticia']);
			echo 
				"<div class='descripcionNoticia' style='font-size:20px'><u>Por<b> " 
					. $datos['escritor'] ."</b>, "
					. $datos['fecha'] . "</u>
				</div>
				<div class='descripcionNoticia'>";
				$noticia = str_replace("[b]", "<b>", $datos['noticia']);
				$noticia = str_replace("[/b]", "</b>", $noticia);
				$noticia = str_replace("[u]", "<u>", $noticia);
				$noticia = str_replace("[/u]", "</u>", $noticia);
				$noticia = str_replace("[title]", "<div class='titularNoticias'>
				", $noticia);
				$noticia = str_replace("[/title]", "</div>", $noticia);
				print(nl2br($noticia) . "</div>");
				?>
		</div>
	</div>
</div>
		<!-- horizontal -->
		<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<ins class="adsbygoogle" style="display:block; text-align:center; margin-bottom: 20px;"
		data-ad-client="ca-pub-3261656417999696" data-ad-slot="3656292990" data-ad-format="auto"
		data-full-width-responsive="true"></ins>
	<script>
		(adsbygoogle = window.adsbygoogle || []).push({});
	</script><div id="footer">
	<div style="width: 33%;">
		<div style="width: 415px; margin-top:10px; margin-left:10px;"><img src="static/originales/logo.png" style="width:50%"></img></div>
		<p1 align="bottom" style="margin-left: 20px; ">© 2019 www.tftesp.com<p1></p1>
	</div>
	<div style="width: 33%;">
		<div style="text-align: center; margin-top: 45px;">
			Teamfight Tactics ESP se creó según la política "Galimatías legal" de Riot Games usando
			recursos que
			son propiedad de Riot Games. Riot Games no respalda ni patrocina este proyecto.
		</div>
	</div>
	<div style="width: 33%; text-align: center;">
		<div style="margin-top:45px;">
			<div style="align-items: center;display: flex;width: 30px;margin: auto;">
				<div>
					<a href="https://twitter.com/TFT_Esp">
						<img src="static/originales/twitter.png" style="width:20px;">
					</a>
				</div>
				<div>
					<a href="https://www.instagram.com/tftesp/">
						<img src="static/originales/instagram.png" style="width:34px;">
					</a>
				</div>
			</div>
			<div style="font-size: 10px;margin-top:10px;">
				<u><a href="contactar.html">Contacto</a></u> /
				<u><a href="politica-de-privacidad.html">Politica de privacidad</a></u> /
				<u><a href="terminos-y-condiciones.html">Terminos y condiciones</a></u>
			</div>
		</div>
	</div>
</div>
</div>
</body>

</html>