<html lang="es">
<head>
	<meta charset="UTF-8"/>
	<link rel="shortcut icon" href="static/originales/icono.ico"/>
	<meta name="description" content="¡Aquí encontrarás toda la información que necesitas sobre Teamfight Tactics!"/>
	<link href="https://fonts.googleapis.com/css?family=Merriweather&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="static/style/style.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
	<script type=" text/javascript" src="static/js/javascriptIndex.js"></script>
	<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-3261656417999696",
          enable_page_level_ads: true
     });
	</script>
  	<title>Inicio - TFTESP</title>
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="@tftesp">
<meta name="twitter:creator" content="@tftesp">
<meta name="twitter:title" content="TftEsp.com">
<meta name="twitter:description"
	content="Conoce la mejor guía de TFT en español y ponte al tanto de las actualizaciones más recientes.">
<meta name="twitter:image:src" content="https://tftesp.com/fotos_head/bienvenidos.png">

</head>
<body id="inicio">
	<div style="display: block;">
		<div id="navbar">
			<a href="index.php">
				<div id="leftbar"><img src="static/originales/logo.png" style="width:110px"></div>
			</a>
			<div id="midbar">
				<a class="selected" href="index.php">INICIO</a>
				<a class="navbarlink" href="campeones.html">CAMPEONES</a>
				<a class="navbarlink" href="objetos.html">OBJETOS</a>
				<a class="navbarlink" href="clases.html">CLASES Y ORIGENES</a>
				<a class="navbarlink" href="composiciones.html">COMPOSICIONES</a>
				<a class="navbarlink" href="constructor.html">CONSTRUCTOR DE EQUIPO</a>
				<a class="navbarlink" href="tabladelideres.php">RANKING</a>
			</div>
			<a href="https://twitter.com/TFT_Esp">
				<div id="rightbar"><img src="static/originales/twitter.png" style="width:18px; padding-top:18px;"></div>
			</a>
			<a href="https://www.instagram.com/tftesp/">
				<div id="rightbar"><img src="static/originales/instagram.png" style="width:34px; padding-top:8px;"></div>
			</a>
			<a href="https://lolesp.com/foros/league-of-legends/general/teamfight-tactics/tft-notas-del-parche-9-16/28447.html">
				<div id="rightbar" style="padding-top:18px; font-size:15px;"><u>Parche: 9.16</u></div>
			</a>
		</div>
		
		
<div id="menu">
	<div style="margin-bottom:15px; text-align:center;">
		<iframe src="https://rcm-eu.amazon-adsystem.com/e/cm?o=30&p=48&l=ez&f=ifr&linkID=4c930a2768f499783233ca22a1283264&t=tftesp-21&tracking_id=tftesp-21" width="728" height="90" scrolling="no" border="0" marginwidth="0" style="border:none;" frameborder="0"></iframe>
		</div>
	<div style="float:left;">
		<a href="https://lolesp.com/" target="_blank"><img style="margin-bottom:18px; width:300px;" src="static/temp/lolesp.png"/></a>
			<div
				style="margin-right:2px;height:590px;  border: 2px solid #c9aa71; background-color: rgb(18,18,18);  border-radius: 10px 10px 10px 10px;">
				<a class="twitter-timeline" data-theme="dark" data-lang="es" data-width="300" data-height="584"
					data-chrome="transparent noscrollbar" style="color:white;" data-link-color="#FAB81E"
					href="https://twitter.com/TFT_Esp?ref_src=twsrc%5Etfw%22%3ETweets by TFT_Esp"></a>
				<script async src="https://platform.twitter.com/widgets.js" charset="utf-8" id="tuits"></script>
			</div>
			
		</div>
	<div id="leftmenu">
		<div id="topleftmenu">
			<a href="campeones.html">
				<div class="title" style="text-align: center">
					<span class="nametitle">BUSCADOR DE USUARIOS</span>
				</div>
			</a>
			<div style="height: 80%">
				<div style="height:10%"></div>
				<div style="height:70%; background: url(static/temp/bannerbuscador.png) no-repeat; "></div>
				<div style="inline-block; margin: auto; width:70%; height:50%;">
					<form action="tabladelideres.php" method="post" class="example">
						<input type="text" required placeholder="Nombre.."
							style="border: 2px solid #c9aa71; background-color: rgb(18,18,18); height:41px; width:70%; color:#c9aa71;"
							name="nombre" />
						<button
							style="border: 2px solid #c9aa71; width:10%; background-color: #c9aa71; color:rgb(18,18,18);"
							type="submit"> <i class="fa fa-search"></i> </button>
						<select
							style="border: 2px solid #c9aa71; background-color: rgb(18,18,18); height:41px; color:#c9aa71; width:20%;"
							name="server">
							<option value="euw">EUW
							<option value="eune">EUNE
							<option value="br">BR
							<option value="na">NA
						</select>
					</form>
				</div>
			</div>
		</div>
		<div id="botleftmenu">
			<div id="cabecera" style=" height: 100%; width: 100%;display: flex; border-radius:10px;position:relative;">
				<div id="anterior" class="divFlecha" style="height:100%;z-index:1;position:absolute;width:60px;">
					<img 
						style="position:absolute;top:40%;left:10px;width:80%; transform: rotate(-180deg);"
						src="static/originales/flecha.png">
				</div>
				<div id="enlace"
					style="width:540px;height:100%; position:absolute;margin-left:auto;margin-right:auto;left:0;right:0;cursor:pointer;">
				</div>
				<div id="tituloCabecera">
				</div>
				<div id="siguiente" class="divFlecha" style="height:100%;z-index:1;position:absolute;right:0px;width:60px;">
					<img  style="position:absolute;top:40%;right:10px;width:80%;" src="static/originales/flecha.png"></div>
			</div>
		</div>
	</div>
	<div id="rightmenu">

		<div class="title" style="text-align: center">
			<span class="nametitle">ÚLTIMAS NOVEDADES</span>
		</div>

		<div class="tierlist">
			<?php
					$con = mysqli_connect("PMYSQL110.dns-servicio.com", "varo", "&qdGw743", "6795849_tftesp");
					mysqli_set_charset($con,'UTF8');
					$resultado = $con->query('select slug, tipo, titular from noticias order by fecha desc');
					while($fila = $resultado->fetch_assoc()){
						echo '<div class="noticia"><a class="linknoticia" href="noticia.php?s='.$fila['slug'].'">['.$fila['tipo'].'] '.$fila['titular'].'</a></div>';
					}
					$con->close();
				?>
		</div>
	</div>
</div>
<!-- horizontal -->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle" style="display:block; text-align:center; margin-bottom: 20px;"
	data-ad-client="ca-pub-3261656417999696" data-ad-slot="3656292990" data-ad-format="auto"
	data-full-width-responsive="true"></ins>
<script>
	(adsbygoogle = window.adsbygoogle || []).push({});
</script>
		
		
		<div id="footer">
	<div style="width: 33%;">
		<div style="width: 415px; margin-top:10px; margin-left:10px;"><img src="static/originales/logo.png" style="width:50%"></img></div>
		<p1 align="bottom" style="margin-left: 20px; ">© 2019 www.tftesp.com<p1></p1>
	</div>
	<div style="width: 33%;">
		<div style="text-align: center; margin-top: 45px;">
			Teamfight Tactics ESP se creó según la política "Galimatías legal" de Riot Games usando
			recursos que
			son propiedad de Riot Games. Riot Games no respalda ni patrocina este proyecto.
		</div>
	</div>
	<div style="width: 33%; text-align: center;">
		<div style="margin-top:45px;">
			<div style="align-items: center;display: flex;width: 30px;margin: auto;">
				<div>
					<a href="https://twitter.com/TFT_Esp">
						<img src="static/originales/twitter.png" style="width:20px;">
					</a>
				</div>
				<div>
					<a href="https://www.instagram.com/tftesp/">
						<img src="static/originales/instagram.png" style="width:34px;">
					</a>
				</div>
			</div>
			<div style="font-size: 10px;margin-top:10px;">
				<u><a href="contactar.html">Contacto</a></u> /
				<u><a href="politica-de-privacidad.html">Politica de privacidad</a></u> /
				<u><a href="terminos-y-condiciones.html">Terminos y condiciones</a></u>
			</div>
		</div>
	</div>
</div>
</div>
</body>

</html>