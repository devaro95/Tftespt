<html lang="es">
<head>
	<meta charset="UTF-8"/>
	<link rel="shortcut icon" href="static/originales/icono.ico"/>
	<meta name="description" content="¡Aquí encontrarás toda la información que necesitas sobre Teamfight Tactics!"/>
	<link href="https://fonts.googleapis.com/css?family=Merriweather&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="static/style/style.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
	<script type=" text/javascript" src="static/js/javascriptIndex.js"></script>
	<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-3261656417999696",
          enable_page_level_ads: true
     });
	</script>
  	<?php
	include 'riotapi.php';
	$controlador = new RiotAPI();
	if(isset($_POST['server']) && $_POST['server'] != null){
		 $servidor = $_POST['server'];
	}else{
		$servidor = 'euw';
	}
	?>
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="@tftesp">
<meta name="twitter:creator" content="@tftesp">
<meta name="twitter:title" content="Estadísticas de usuario">
<meta name="twitter:description"
	content="Busca las estadísticas de todos los usuarios de TFT y compáralas con los más grandes.">
<meta name="twitter:image:src" content="https://tftesp.com/fotos_head/estadisticas.png">

</head>
<body id="inicio">
	<div style="display: block;">
		<div id="navbar">
			<a href="index.php">
				<div id="leftbar"><img src="static/originales/logo.png" style="width:110px"></div>
			</a>
			<div id="midbar">
				<a class="navbarlink" href="index.php">INICIO</a>
				<a class="navbarlink" href="campeones.html">CAMPEONES</a>
				<a class="navbarlink" href="objetos.html">OBJETOS</a>
				<a class="navbarlink" href="clases.html">CLASES Y ORIGENES</a>
				<a class="navbarlink" href="composiciones.html">COMPOSICIONES</a>
				<a class="navbarlink" href="constructor.html">CONSTRUCTOR DE EQUIPO</a>
				<a class="selected" href="tabladelideres.php">RANKING</a>
			</div>
			<a href="https://twitter.com/TFT_Esp">
				<div id="rightbar"><img src="static/originales/twitter.png" style="width:18px; padding-top:18px;"></div>
			</a>
			<a href="https://www.instagram.com/tftesp/">
				<div id="rightbar"><img src="static/originales/instagram.png" style="width:34px; padding-top:8px;"></div>
			</a>
			<a href="https://lolesp.com/foros/league-of-legends/general/teamfight-tactics/tft-notas-del-parche-9-16/28447.html">
				<div id="rightbar" style="padding-top:18px; font-size:15px;"><u>Parche: 9.16</u></div>
			</a>
		</div>
<div id="menu">
	<?php if(isset($_POST['nombre']) && $_POST['nombre'] != null){ 
	$datosClasificatorias = $controlador->obtenerUsuario($servidor,$_POST['nombre']);
	$datos = RiotAPI::obtenerInfoRankeds($_POST['server'], $datosClasificatorias['id']);
	if($datos != NULL){
?>
	<div
		style="min-width: 1300px;width:65%; border:solid #c9aa71; margin: auto; background: rgb(18,18,18, 0.75); text-align: center;">
		<div
			style="width: 100%;height: 35px;border-bottom: solid #c9aa71 3px;color:#c9aa71;background: rgb(18,18,18); height:60px; line-height: 60px; margin-bot:100px; ">
			<div style="display: flex;margin: auto;">
				<div style="width: 30%;">
					NOMBRE INVOCADOR
				</div>
				<div style="width: 20%;">
					RANGO
				</div>
				<div style="width: 10%;">
					PUNTOS
				</div>
				<div style="width: 10%;">
					WIN RATE
				</div>
				<div style="width: 10%;">
					VICTORIAS
				</div>
				<div style="width: 10%;">
					DERROTAS
				</div>
				<div style="width: 10%;">
					JUGADO
				</div>
			</div>
		</div>
		<div
			style="width: 100%;height: 50px; border-bottom: solid #c9aa71 1px;color:#c9aa71; line-height: 50px; margin-bot:100px;">
			<div style="display: flex;margin: auto;">
				<div style="width: 30%;">
					<?php echo $datos['summonerName'] ?>
				</div>
				<div style="width: 20%;display: flex;">
					<div style="margin:auto;display: flex;">
						<div>
							<img src="static/base-icons/<?php echo strtolower($datos['tier']);  ?>.png"
								style="width: 40px;margin-top: 5px;" />
						</div>
						<div>
							<?php echo $datos['tier'] . " " . $datos['rank']?>
						</div>
					</div>
				</div>
				<div style="width: 10%;">
					<?php echo $datos['leaguePoints'] ?>
				</div>
				<div style="width: 10%;">
					<?php echo number_format($datos['wins']/ ($datos['wins']+$datos['losses'])*100, 2) . "%"?>
				</div>
				<div style="width: 10%;">
					<?php echo $datos['wins'] ?>
				</div>
				<div style="width: 10%;">
					<?php echo $datos['losses'] ?>
				</div>
				<div style="width: 10%;">
					<?php echo $datos['wins']+$datos['losses'] ?>
				</div>
			</div>
		</div>
	</div>
	<div style="height:50px;"></div>
	<?php }} ?>
	<!-- horizontal -->
	<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<ins class="adsbygoogle" style="display:block; text-align:center; margin-bottom: 20px;"
		data-ad-client="ca-pub-3261656417999696" data-ad-slot="3656292990" data-ad-format="auto"
		data-full-width-responsive="true"></ins>
	<script>
		(adsbygoogle = window.adsbygoogle || []).push({});
	</script>
	<form action="tabladelideres.php" method="post">
		<div style="width:50%; border:solid #c9aa71; margin: auto;margin-bottom:10px; text-align: center;">
			<div style="width: 100%;color:#c9aa71;  margin-bot:100px; ">
				<div style="display: flex;margin: auto;">
					<div style="width: 25%;border-right: solid 1px; 
								background: rgb(18,18,18);">
						<button name="server" value="euw"
							style="cursor:pointer;width: 100%; background: none; border: 0; line-height: 30px; color:#c9aa71;"
							type="submit">
							EUW
						</button>
					</div>
					<div style="width: 25%;border-right: solid 1px; 
							background: rgb(18,18,18, 0.75);">
						<button name="server" value="na"
							style="cursor:pointer;width: 100%; background: none; border: 0; line-height: 30px; color:#c9aa71;"
							type="submit">
							NA
						</button>
					</div>
					<div style="width: 25%;border-right: solid 1px;
							background: rgb(18,18,18, 0.75);">
						<button name="server" value="eune"
							style="cursor:pointer;width: 100%; background: none; border: 0; line-height: 30px; color:#c9aa71;"
							type="submit">
							EUNE
						</button>
					</div>
					<div style="width: 25%;
							background: rgb(18,18,18, 0.75);">
						<button name="server" value="br"
							style="cursor:pointer;width: 100%; background: none; border: 0; line-height: 30px; color:#c9aa71;"
							type="submit">
							BR
						</button>
					</div>
				</div>
			</div>
		</div>
	</form>

	<div
		style="min-width: 1300px;width:65%; border:solid #c9aa71; margin: auto; background: rgb(18,18,18, 0.75); text-align: center;">
		<div
			style="width: 100%;height: 35px;border-bottom: solid #c9aa71 3px;color:#c9aa71;background: rgb(18,18,18); height:60px; line-height: 60px; margin-bot:100px; ">
			<div style="display: flex;margin: auto;">
				<div style="width: 10%;">
					POSICION
				</div>
				<div style="width: 30%;">
					NOMBRE INVOCADOR
				</div>
				<div style="width: 20%;">
					RANGO
				</div>
				<div style="width: 10%;">
					PUNTOS
				</div>
				<div style="width: 10%;">
					WIN RATE
				</div>
				<div style="width: 10%;">
					VICTORIAS
				</div>
				<div style="width: 10%;">
					DERROTAS
				</div>
				<div style="width: 10%;">
					JUGADO
				</div>
			</div>
		</div>

		<?php 
				$cuenta = 1;
				$dato = $controlador->ranking($servidor,'challenger');
				
				foreach((array) $dato['entries'] as $fila){
					
				?>
		<div style="width: 100%;height: 50px; border-bottom: solid #c9aa71 1px;color:#c9aa71; line-height: 50px;">
			<div style="display: flex;margin: auto;">
				<div style="width: 10%;">
					<?php echo $cuenta ?>
				</div>
				<div style="width: 30%;">
					<?php echo $fila['summonerName'] ?>
				</div>
				<div style="width: 20%;display: flex;">
					<div style="margin:auto;display: flex;">
						<div>
							<img src="static/base-icons/<?php echo strtolower($dato['tier']);  ?>.png"
								style="width: 40px;margin-top: 5px;" />
						</div>
						<div>
							<?php echo $dato['tier']?>
						</div>
					</div>
				</div>
				<div style="width: 10%;">
					<?php echo $fila['leaguePoints'] ?>
				</div>
				<div style="width: 10%;">
					<?php echo number_format($fila['wins']/ ($fila['wins']+$fila['losses'])*100, 2) . "%"?>
				</div>
				<div style="width: 10%;">
					<?php echo $fila['wins'] ?>
				</div>
				<div style="width: 10%;">
					<?php echo $fila['losses'] ?>
				</div>
				<div style="width: 10%;">
					<?php echo $fila['wins']+$fila['losses'] ?>
				</div>
			</div>
		</div>
		<?php 
						$cuenta = $cuenta + 1;
				}
					
				?>

		<?php 
				
				$dato = $controlador->ranking($servidor,'grandmaster');
				
				foreach((array) $dato['entries'] as $fila){
					
				?>
		<div style="width: 100%;height: 50px; border-bottom: solid #c9aa71 1px;color:#c9aa71; line-height: 50px;">
			<div style="display: flex;margin: auto;">
				<div style="width: 10%;">
					<?php echo $cuenta ?>
				</div>
				<div style="width: 30%;">
					<?php echo $fila['summonerName'] ?>
				</div>
				<div style="width: 20%;display: flex;">
					<div style="margin:auto;display: flex;">
						<div>
							<img src="static/base-icons/<?php echo strtolower($dato['tier']); ?>.png"
								style="width: 40px;margin-top: 5px;">
						</div>
						<div>
							<?php echo $dato['tier']?>
						</div>
					</div>
				</div>
				<div style="width: 10%;">
					<?php echo $fila['leaguePoints'] ?>
				</div>
				<div style="width: 10%;">
					<?php echo number_format($fila['wins']/ ($fila['wins']+$fila['losses'])*100, 2) . "%"?>
				</div>
				<div style="width: 10%;">
					<?php echo $fila['wins'] ?>
				</div>
				<div style="width: 10%;">
					<?php echo $fila['losses'] ?>
				</div>
				<div style="width: 10%;">
					<?php echo $fila['wins']+$fila['losses'] ?>
				</div>
			</div>
		</div>
		<?php 
						$cuenta = $cuenta + 1;
				}
					
				?>

		<?php 
				
				$dato = $controlador->ranking($servidor,'master');
				foreach((array) $dato['entries'] as $fila){
					
				?>
		<div style="width: 100%;height: 50px; border-bottom: solid #c9aa71 1px;color:#c9aa71; line-height: 50px;">
			<div style="display: flex;margin: auto;">
				<div style="width: 10%;">
					<?php echo $cuenta ?>
				</div>
				<div style="width: 30%;">
					<?php echo $fila['summonerName'] ?>
				</div>
				<div style="width: 20%;display: flex;">
					<div style="margin:auto;display: flex;">
						<div>
							<img src="static/base-icons/<?php echo strtolower($dato['tier']);  ?>.png"
								style="width: 40px;margin-top: 5px;" />
						</div>
						<div>
							<?php echo $dato['tier']?>
						</div>
					</div>
				</div>
				<div style="width: 10%;">
					<?php echo $fila['leaguePoints'] ?>
				</div>
				<div style="width: 10%;">
					<?php echo number_format($fila['wins']/ ($fila['wins']+$fila['losses'])*100, 2) . "%"?>
				</div>
				<div style="width: 10%;">
					<?php echo $fila['wins'] ?>
				</div>
				<div style="width: 10%;">
					<?php echo $fila['losses'] ?>
				</div>
				<div style="width: 10%;">
					<?php echo $fila['wins']+$fila['losses'] ?>
				</div>
			</div>
		</div>
		<?php 
						$cuenta = $cuenta + 1;
				}
					
				?>
	</div>
	<div>
		<div style="height:100px;"></div>

		<!-- horizontal -->
		<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
		<ins class="adsbygoogle" style="display:block; text-align:center; margin-bottom: 20px;"
			data-ad-client="ca-pub-3261656417999696" data-ad-slot="3656292990" data-ad-format="auto"
			data-full-width-responsive="true"></ins>
		<script>
			(adsbygoogle = window.adsbygoogle || []).push({});
		</script><div id="footer">
	<div style="width: 33%;">
		<div style="width: 415px; margin-top:10px; margin-left:10px;"><img src="static/originales/logo.png" style="width:50%"></img></div>
		<p1 align="bottom" style="margin-left: 20px; ">© 2019 www.tftesp.com<p1></p1>
	</div>
	<div style="width: 33%;">
		<div style="text-align: center; margin-top: 45px;">
			Teamfight Tactics ESP se creó según la política "Galimatías legal" de Riot Games usando
			recursos que
			son propiedad de Riot Games. Riot Games no respalda ni patrocina este proyecto.
		</div>
	</div>
	<div style="width: 33%; text-align: center;">
		<div style="margin-top:45px;">
			<div style="align-items: center;display: flex;width: 30px;margin: auto;">
				<div>
					<a href="https://twitter.com/TFT_Esp">
						<img src="static/originales/twitter.png" style="width:20px;">
					</a>
				</div>
				<div>
					<a href="https://www.instagram.com/tftesp/">
						<img src="static/originales/instagram.png" style="width:34px;">
					</a>
				</div>
			</div>
			<div style="font-size: 10px;margin-top:10px;">
				<u><a href="contactar.html">Contacto</a></u> /
				<u><a href="politica-de-privacidad.html">Politica de privacidad</a></u> /
				<u><a href="terminos-y-condiciones.html">Terminos y condiciones</a></u>
			</div>
		</div>
	</div>
</div>
</div>
</body>

</html>